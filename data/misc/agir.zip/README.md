# agir 
Dumping ground for my experiments with Connectomes, ML, Spiking Neural Networks etc. 

## Packages

* `pkg/goml` - ML related functions
* `pkg/tcf`  - The Connectome Framework
* `pkg/idxfile` - Functions for reading `idx` files


### TCF
`TCF` or `The-Connectome-Framework` is a `Golang` framework for building/experimenting with connectome.

See `data/connectome/` for connectome (e.g. C.Elegans) model files.
