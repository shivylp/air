-- Simple TCF Connectome Simulation Script
-- Run as `agir -m data/connectome/c-elegans1.yaml -s simulations/simple.lua`

function onStimulateHandler(cell, strength)
    return true
end


function onFireHandler(cell)
    return true
end


session:OnStimulate(onStimulateHandler)
session:OnFire(onFireHandler)


-- Start simulation here

i = 1
while i < 10 do
    api:FireCell("FLPR")
    api:FireCell("FLPL")
    api:FireCell("ASHL")
    api:FireCell("ASHR")
    api:FireCell("IL1VL")
    api:FireCell("IL1VR")
    api:FireCell("OLQDL")
    api:FireCell("OLQDR")
    api:FireCell("OLQVR")
    api:FireCell("OLQVL")
    api:Run()
    cells = api:GetAllActiveCells()
    print(#cells .. " cells active after iteration-" .. i)
    i = i + 1
end

