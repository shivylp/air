print("hello"); print("hello")
