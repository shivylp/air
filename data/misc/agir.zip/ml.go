package main

import "github.com/spf13/cobra"

func init() {
	rootCmd.AddCommand(newMLCmd())
}

func newMLCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "ml",
		Short: "ML related commands",
	}

	return cmd
}
