// Package idxfile provides functions to read data from IDX
// files (e.g. MNIST data files)
package idxfile
