package idxfile

import (
	"bytes"
	"encoding/binary"
	"fmt"
	"io"
)

// IDXDataType represents the different IDX data formats
type IDXDataType struct {
	code     int
	name     string
	numBytes int
}

// Create an IdxDataType from the specified byte.
func makeIDXDataType(dataType byte) (IDXDataType, error) {
	var idxDataType IDXDataType
	var err error
	switch {
	case dataType == 0x08:
		idxDataType = IDXDataType{0x08, "unsigned", 1}
	case dataType == 0x09:
		idxDataType = IDXDataType{0x09, "signed", 1}
	case dataType == 0x0B:
		idxDataType = IDXDataType{0x0B, "short", 2}
	case dataType == 0x0C:
		idxDataType = IDXDataType{0x0C, "int", 4}
	case dataType == 0x0D:
		idxDataType = IDXDataType{0x0D, "float", 4}
	case dataType == 0x0E:
		idxDataType = IDXDataType{0x0E, "double", 4}
	case true:
		err = fmt.Errorf("Unknown IdxDataType for byte: %x", dataType)
	}
	return idxDataType, err
}

// IDXMagic represents magic number of an IdxHeader.
type IDXMagic struct {
	nilBytes      bool
	dataType      IDXDataType
	numDimensions int
}

// Create an IdxMagic from the specified magic bytes.
func makeIDXMagic(magicBytes []byte) IDXMagic {
	nilBytes, _ := makeNilBytes(magicBytes[0:2])
	idxDataType, _ := makeIDXDataType(magicBytes[2:3][0])
	numDimensions, _ := makeNumDimensions(magicBytes[3:])
	return IDXMagic{nilBytes, idxDataType, numDimensions}
}

// Return true if the specified magic bytes have the required number of nil bytes.
func makeNilBytes(nilBytes []byte) (bool, error) {
	var result bool
	var err error
	value, _ := binary.Uvarint(nilBytes)
	if len(nilBytes) == 2 && value == 0 {
		result = true
	} else {
		err = fmt.Errorf("Bad nilByte in header: %x", nilBytes)
	}
	return result, err
}

// Return the number of dimensions specified in the dimension byte of the magic number header.
func makeNumDimensions(numDimByte []byte) (int, error) {
	// return int(numDimByte[0]), nil
	var numDimensions uint8
	err := binary.Read(bytes.NewReader(numDimByte), binary.BigEndian, &numDimensions)
	return int(numDimensions), err
}

// IDXHeader represents the header structure of an IDX format file
type IDXHeader struct {
	idxMagic   IDXMagic
	dimensions []uint32
}

func makeDimension(dimensionBytes []byte) (uint32, error) {
	var dimension uint32
	err := binary.Read(bytes.NewReader(dimensionBytes), binary.BigEndian, &dimension)
	return dimension, err
}

func (idx *IDXHeader) fileHeaderOffset() int {
	return 4 + (idx.idxMagic.numDimensions * 4)
}

// ReadIDXHeader reads the IDXHeader from an IDX data format file
func ReadIDXHeader(idxFile io.ReadSeeker) (*IDXHeader, error) {
	idxFile.Seek(0, 0)
	magicBytes, err := readBytes(idxFile, 4)
	if err != nil {
		return nil, err
	}

	idxMagic := makeIDXMagic(magicBytes)
	dimensions := make([]uint32, idxMagic.numDimensions)
	for n := 0; n < idxMagic.numDimensions; n++ {
		dimNBytes, err := readBytes(idxFile, 4)
		if err != nil {
			return nil, err
		}
		dimensions[n], err = makeDimension(dimNBytes)
		if err != nil {
			return nil, err
		}
	}
	return &IDXHeader{idxMagic, dimensions}, nil
}

func readBytes(file io.Reader, numBytes int) ([]byte, error) {
	bytes := make([]byte, numBytes)
	_, err := file.Read(bytes)
	return bytes, err
}

func appendError(errors []error, error error) []error {
	return append(errors, error)
}
