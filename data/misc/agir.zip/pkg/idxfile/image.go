package idxfile

import (
	"image"
	"image/png"
	"io"
)

// ByteImage is in-memory image stored as a consecuative array of bytes.
type ByteImage struct {
	width  int
	height int
	bytes  []byte
}

// Pixels gets the image bytes as a formatted matrix.
func (img *ByteImage) Pixels() [][]byte {
	byteIdx := 0
	pixels := make([][]byte, img.height)
	for rowIdx := 0; rowIdx < img.height; rowIdx++ {
		pixels[rowIdx] = make([]byte, img.width)
		for colIdx := 0; colIdx < img.width; colIdx++ {
			pixels[rowIdx][colIdx] = img.bytes[byteIdx]
			byteIdx++
		}
	}
	return pixels
}

// ReadIDXImage reads a ByteImage from an IDX format data file.
func ReadIDXImage(idxFile io.ReadSeeker, imageIdx int) (*ByteImage, error) {
	idxHeader, err := ReadIDXHeader(idxFile)
	if err != nil {
		return nil, err
	}

	fileHeaderOffset := int(idxHeader.fileHeaderOffset())
	dataWidth := int(idxHeader.idxMagic.dataType.numBytes)
	imgWidth := int(idxHeader.dimensions[1])
	imgHeight := int(idxHeader.dimensions[2])
	imgSize := imgWidth * imgHeight * dataWidth

	currentOffset, _ := idxFile.Seek(0, 1)
	startOffset := int64(fileHeaderOffset + (imgSize * imageIdx))
	endOffset := startOffset + int64(imgSize)

	idxFile.Seek(startOffset-currentOffset, 1)
	imageBytes := make([]byte, endOffset-startOffset)
	_, err = idxFile.Read(imageBytes)
	if err != nil {
		return nil, err
	}

	img := &ByteImage{imgWidth, imgHeight, imageBytes}
	return img, err
}

// ReadIDXImages reads a set of ByteImages from an IDX format data file.
func ReadIDXImages(idxFile io.ReadSeeker, imageIdxs []int) ([]ByteImage, error) {
	numImages := len(imageIdxs)
	images := make([]ByteImage, numImages)
	for i := 0; i < numImages; i++ {
		image, err := ReadIDXImage(idxFile, i)
		if err != nil {
			return nil, err
		}
		images[i] = *image
	}
	return images, nil
}

// ReadAllIDXImages reads all ByteImages from an IDX format data file.
func ReadAllIDXImages(idxFile io.ReadSeeker) ([]ByteImage, error) {
	idxHeader, err := ReadIDXHeader(idxFile)
	if err != nil {
		return nil, err
	}
	numImages := int(idxHeader.dimensions[0])
	images := make([]ByteImage, numImages)
	for i := 0; i < numImages; i++ {
		image, err := ReadIDXImage(idxFile, i)
		if err != nil {
			return nil, err
		}
		images[i] = *image
	}
	return images, nil
}

// WritePNGImage generates a PNG format image file from the speicified ByteImage.
func WritePNGImage(byteImage ByteImage, pngFile io.Writer) error {
	imgWidth := byteImage.width
	imgHeight := byteImage.height

	imgRect := image.Rect(0, 0, imgWidth, imgHeight)
	img := image.NewGray(imgRect)
	img.Pix = byteImage.bytes
	img.Stride = imgWidth

	err := png.Encode(pngFile, img)
	if err != nil {
		return err
	}
	return err
}
