package idxfile

import (
	"fmt"
	"io"
)

// LabelledImage represents a pair of image and the associated
// label
type LabelledImage struct {
	Image ByteImage
	Label int
}

// ReadLabelledImage reads a labelled image from idx stream
func ReadLabelledImage(imageFile io.ReadSeeker, labelFile io.ReadSeeker, idx int) (LabelledImage, error) {
	var labelledImage LabelledImage
	// read image
	image, err := ReadIDXImage(imageFile, idx)
	if err != nil {
		return labelledImage, err
	}
	// read label
	label, err := ReadIDXLabel(labelFile, idx)
	if err != nil {
		return labelledImage, err
	}

	labelledImage = LabelledImage{*image, label}
	return labelledImage, err
}

// ReadLabelledImages reads label and image data of given ids
func ReadLabelledImages(imageFile io.ReadSeeker, labelFile io.ReadSeeker, idxs []int) ([]LabelledImage, error) {
	var err error
	numLabelledImages := len(idxs)
	labelledImages := make([]LabelledImage, numLabelledImages)
	for i := 0; i < numLabelledImages; i++ {
		labelledImages[i], err = ReadLabelledImage(imageFile, labelFile, i)
		if err != nil {
			return labelledImages, err
		}
	}
	return labelledImages, err
}

// ReadAllLabelledImages reads all LabelledImages from IDX format data files.
func ReadAllLabelledImages(imageFile io.ReadSeeker, labelFile io.ReadSeeker) ([]LabelledImage, error) {
	var labelledImages []LabelledImage
	var err error
	imageIdxHeader, _ := ReadIDXHeader(imageFile)
	numImages := int(imageIdxHeader.dimensions[0])
	labelIdxHeader, _ := ReadIDXHeader(labelFile)
	numLabels := int(labelIdxHeader.dimensions[0])
	if numImages != numLabels {
		return labelledImages, fmt.Errorf("Inconsistent number of iamges and labels %d != %d", numImages, numLabels)
	}
	// extract images
	labelledImages = make([]LabelledImage, numImages)
	for i := 0; i < numImages; i++ {
		labelledImages[i], _ = ReadLabelledImage(imageFile, labelFile, i)
	}
	return labelledImages, err
}
