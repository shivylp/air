package idxfile

import "io"

// ReadIDXLabel reads a label for the given image id from an idx label file
func ReadIDXLabel(idxFile io.ReadSeeker, imageIdx int) (int, error) {
	idxHeader, _ := ReadIDXHeader(idxFile)

	fileHeaderOffset := int(idxHeader.fileHeaderOffset())
	dataWidth := int(idxHeader.idxMagic.dataType.numBytes)

	currentOffset, _ := idxFile.Seek(0, 1)
	startOffset := int64(fileHeaderOffset + imageIdx)
	endOffset := startOffset + int64(dataWidth)

	idxFile.Seek(startOffset-currentOffset, 1)
	labelBytes := make([]byte, endOffset-startOffset)
	_, err := idxFile.Read(labelBytes)

	label := int(labelBytes[0])
	return label, err
}
