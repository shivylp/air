package tcf

// New initializes a new API around the given Connectome object
func New(con *Connectome, handler Handler) *API {
	api := &API{}
	api.Connectome = con
	api.handler = &handlerWrapper{handler}
	return api
}

// API provides functions to manipulate the connectome
type API struct {
	*Connectome

	handler Handler
}

// Run the connectome. Run identifies all the cells whose states
// are greater than their thresholds and simulates firing of those
// cells.
func (api *API) Run() {
	for name, cell := range api.Cells {
		if cell.IsActive() {
			api.FireCell(name)
		}
	}
}
