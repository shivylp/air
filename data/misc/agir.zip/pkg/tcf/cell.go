package tcf

// Cell represents a single cell in the network with its
// specific properties and the synaptic strenghts to the
// post-synaptic neurons
type Cell struct {
	Threshold    float64            `json:"threshold" yaml:"threshold"`
	Synapses     map[string]float64 `json:"synapses" yaml:"synapses"`
	RestingState float64            `json:"resting_state" yaml:"resting_state"`

	state float64
}

// State returns the current state of the cell
func (cell Cell) State() float64 {
	return cell.state
}

// Stimulate the cell with given strength
func (cell *Cell) Stimulate(strength float64) {
	cell.state += strength
}

// Reset the cell state to zero
func (cell *Cell) Reset() {
	cell.state = cell.RestingState
}

// IsActive checks if the cell state is higher than
// the threshold
func (cell Cell) IsActive() bool {
	return cell.state > cell.Threshold
}
