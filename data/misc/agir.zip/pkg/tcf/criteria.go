package tcf

// Criterion is used to filter the cells by Connectome.GetCells method
type Criterion func(name string, cell Cell) bool

// WithStateGreaterThan returns all cells with state which is greater
// than given threshold
func WithStateGreaterThan(threshold float64) Criterion {
	return func(name string, cell Cell) bool {
		return cell.State() > threshold
	}
}

func WithActiveState() Criterion {
	return func(name string, cell Cell) bool {
		return cell.IsActive()
	}
}
