package tcf

import (
	"github.com/yuin/gopher-lua"
	luar "layeh.com/gopher-luar"
)

// NewWrapper creates a new wrapper around the given api instance
// with lua scripting enabled
func NewWrapper(con *Connectome, logger Logger) (*Wrapper, error) {
	wapi := &Wrapper{}
	wapi.con = con
	wapi.luaState = lua.NewState()
	wapi.Logger = logger
	wapi.lh = &luaHandler{
		state: wapi.luaState,
	}
	wapi.api = New(con, wapi.lh)
	if wapi.con.LuaScript != "" {
		if err := wapi.loadLuaScript(wapi.con.LuaScript); err != nil {
			return nil, err
		}
	}
	return wapi, nil
}

// Logger provides common logging functions
type Logger interface {
	Infof(format string, args ...interface{})
	Warnf(format string, args ...interface{})
	Errorf(format string, args ...interface{})
}

// Wrapper represents the wrapper around the connectome API
type Wrapper struct {
	Logger

	con *Connectome
	lh  *luaHandler
	api *API

	luaState *lua.LState
}

// IsScriptEnabled returns true if a Lua script is loaded
func (ins *Wrapper) IsScriptEnabled() bool {
	return ins.con.LuaScript != ""
}

// API returns the pointer to current api instance
func (ins *Wrapper) API() *API {
	return ins.api
}

// Connectome returns pointer to the current connectome instance
func (ins *Wrapper) Connectome() *Connectome {
	return ins.con
}

// OnFire allows lua scripts to register callback for particular
// cells
func (ins *Wrapper) OnFire(fn *lua.LFunction) {
	ins.lh.onFire = fn
}

// OnStimulate allows lua scripts to register callback for particular
// cells
func (ins *Wrapper) OnStimulate(fn *lua.LFunction) {
	ins.lh.onStimulate = fn
}

// loadLuaScript reads and loads a new lua script. Connectome
// wrapper will be available as 'api' for functions in the
// lua script
func (ins *Wrapper) loadLuaScript(fileName string) error {
	ins.luaState.SetGlobal("session", luar.New(ins.luaState, ins))
	ins.luaState.SetGlobal("api", luar.New(ins.luaState, ins.api))

	if err := ins.luaState.DoFile(fileName); err != nil {
		return err
	}
	return nil
}
