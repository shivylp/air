package tcf

import (
	"log"

	lua "github.com/yuin/gopher-lua"
)

// Handler can be provided to intercept connectome events
type Handler interface {
	OnFire(cellName string)
	OnStimulate(cellName string, strength float64)
}

type handlerWrapper struct {
	handler Handler
}

func (hw handlerWrapper) OnFire(cellName string) {
	if hw.handler != nil {
		hw.handler.OnFire(cellName)
	}
}

func (hw handlerWrapper) OnStimulate(cellName string, strength float64) {
	if hw.handler != nil {
		hw.handler.OnStimulate(cellName, strength)
	}
}

type luaHandler struct {
	state       *lua.LState
	onFire      *lua.LFunction
	onStimulate *lua.LFunction
}

func (lh luaHandler) OnFire(cellName string) {
	if lh.onFire != nil {
		lh.state.Push(lh.onFire)
		lh.state.Push(lua.LString(cellName))

		// one argument and one return value
		err := lh.state.PCall(1, 1, nil)
		if err != nil {
			log.Printf("err: %s", err)
		}

		top := lh.state.GetTop()
		returnValue := lh.state.Get(top)
		if returnValue.Type() != lua.LTBool {
			log.Printf("invalid return value: %s", returnValue)
		}
	}
}

func (lh luaHandler) OnStimulate(cellName string, strength float64) {
	if lh.onStimulate != nil {
		lh.state.Push(lh.onStimulate)
		lh.state.Push(lua.LString(cellName))
		lh.state.Push(lua.LNumber(strength))

		// one argument and one return value
		err := lh.state.PCall(2, 1, nil)
		if err != nil {
			log.Printf("err: %s", err)
		}

		top := lh.state.GetTop()
		returnValue := lh.state.Get(top)
		if returnValue.Type() != lua.LTBool {
			log.Printf("invalid return value: %s", returnValue)
		}
	}
}
