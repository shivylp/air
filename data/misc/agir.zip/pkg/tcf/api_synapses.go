package tcf

// AddSynapse adds a new synapse from preCell to postCell with given
// strength
func (api *API) AddSynapse(preCell string, postCell string, strength float64) {
	cell, exists := api.Cells[preCell]
	if !exists {
		cell = Cell{}
		api.Cells[preCell] = cell
	}

	if s, exists := cell.Synapses[postCell]; exists {
		strength += s
	}

	cell.Synapses[postCell] = strength
	api.Cells[preCell] = cell
}
