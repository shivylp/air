package tcf

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"

	yaml "gopkg.in/yaml.v2"
)

// FromFile reads the connectome model from a yaml or json file.
// File type will be inferred from the extension
func FromFile(fileName string) (*Connectome, error) {
	file, err := os.Open(fileName)
	if err != nil {
		return nil, err
	}

	con := &Connectome{}

	if strings.HasSuffix(fileName, ".json") {
		if err := json.NewDecoder(file).Decode(con); err != nil {
			return nil, err
		}
	} else if strings.HasSuffix(fileName, ".yaml") || strings.HasSuffix(fileName, ".yml") {
		if err := yaml.NewDecoder(file).Decode(con); err != nil {
			return nil, err
		}
	} else {
		return nil, fmt.Errorf("unknown file type: %s", fileName)
	}

	if err := con.Init(); err != nil {
		return nil, err
	}

	return con, nil
}

// Connectome stores the pre-synaptic to post-synaptic
// network connections and the network configurations
type Connectome struct {
	Attributes `json:"attributes" yaml:"attributes"`
	Cells      map[string]Cell `json:"cells" yaml:"cells"`
}

// PrintStats displays stats about the connectome
func (con Connectome) PrintStats() {
	fmt.Printf("Name	   : %s\n", con.Name)
	fmt.Printf("Cells      : %d\n", len(con.Cells))
	fmt.Printf("Threshold  : %f\n", con.Threshold)
	fmt.Printf("Rest-State : %f\n", con.RestingState)
}

// Init must be called before running any other functions.
func (con *Connectome) Init() error {
	if con.Cells == nil {
		con.Cells = map[string]Cell{}
	}
	if con.RestingState != 0 {
		for n, cell := range con.Cells {
			if cell.RestingState == 0 {
				cell.RestingState = con.RestingState
				con.Cells[n] = cell
			}
		}
	}

	return nil
}

// Attributes represents the attributes of the connectome
type Attributes struct {
	Name         string  `json:"name" yaml:"name"`
	Threshold    float64 `json:"threshold" yaml:"threshold"`
	RestingState float64 `json:"resting_state" yaml:"resting_state"`
	LuaScript    string  `json:"lua_script" yaml:"lua_script"`
}
