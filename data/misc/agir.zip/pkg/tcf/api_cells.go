package tcf

import "fmt"

// FireCell stimulates all the post-synaptic cells connected to the
// cell identified by name, thus simulating the activation of the
// cell
func (api *API) FireCell(name string) error {
	cell, found := api.Cells[name]
	if !found {
		return fmt.Errorf("no such cell: %s", name)
	}
	api.handler.OnFire(name)

	for postCell, strength := range cell.Synapses {
		if err := api.StimulateCell(postCell, strength); err != nil {
			return err
		}
	}

	cell.Reset()
	api.Cells[name] = cell
	return nil
}

// StimulateCell stimulates the cell or changes the state of
// the cell
func (api *API) StimulateCell(name string, strength float64) error {
	cell, found := api.Cells[name]
	if !found {
		return fmt.Errorf("no such cell: %s", name)
	}

	cell.Stimulate(strength)
	api.Cells[name] = cell
	api.handler.OnStimulate(name, strength)
	return nil
}

// IsCell returns if a cell with given name exists
func (api *API) IsCell(cellName string) bool {
	_, exists := api.Cells[cellName]
	return exists
}

// GetCellState returns state of the cell
func (api *API) GetCellState(cellName string) float64 {
	if cell, found := api.Cells[cellName]; found {
		return cell.state
	}

	return 0
}

// GetCells returns all cells matching the given criterion function
func (api API) GetCells(criterion Criterion) map[string]Cell {
	cells := map[string]Cell{}
	for name, cell := range api.Cells {
		if criterion(name, cell) {
			cells[name] = cell
		}
	}
	return cells
}

// GetAllActiveCells returns all the cells which are currently active
func (api API) GetAllActiveCells() []string {
	m := api.GetCells(WithActiveState())
	cellNames := []string{}
	for cn := range m {
		cellNames = append(cellNames, cn)
	}

	return cellNames
}
