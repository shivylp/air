// Package tcf provides APIs and models for creating/manipulating
// connectomes. tcf stands for The-Connectome-Framework.
package tcf
