// Package goml provides ML related functions and algorithm
// implementations
package goml
