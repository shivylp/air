package goml

import "fmt"

// New initializes a perceptron unit
func New(inputSize int, threshold float64) *Unit {
	unit := &Unit{}
	unit.weights = make([]float64, inputSize)
	unit.threshold = threshold
	return unit
}

// WithWeights initializes a perceptron unit using the given
// weight slice
func WithWeights(weights []float64, threshold float64) *Unit {
	unit := New(len(weights), threshold)
	unit.weights = weights
	return unit
}

// Unit represents a single perceptron cell
type Unit struct {
	weights   []float64
	threshold float64
}

// Predict calculates the output for the given inputs
func (unit Unit) Predict(inputs []float64) (bool, error) {
	if iL, wL := len(inputs), len(unit.weights); iL != wL {
		return false, fmt.Errorf("input length must be %d (not %d)", wL, iL)
	}

	sum := 0.0
	for i := 0; i < len(inputs); i++ {
		sum += unit.weights[i] * inputs[i]
	}

	return sum > unit.threshold, nil
}
