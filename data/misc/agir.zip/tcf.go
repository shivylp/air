package main

import (
	"fmt"
	"os"

	"github.com/shivylp/agir/pkg/tcf"
	"github.com/spf13/cobra"
)

func init() {
	rootCmd.AddCommand(newTcfCmd())
	rootCmd.AddCommand(newREPLCmd())
}

func newREPLCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "repl",
		Short: "TCF REPL for playing with the model",
	}
	cmd.Run = func(cmd *cobra.Command, args []string) {

	}

	return cmd
}

func newTcfCmd() *cobra.Command {
	rootCmd := &cobra.Command{
		Use:   "tcf",
		Short: "The Connectome Framework",
	}
	rootCmd.PersistentFlags().StringP("model", "m", "", "Connectome Model File (yaml or json)")
	rootCmd.PersistentFlags().StringP("script", "s", "", "Load Lua script")

	rootCmd.Run = func(cmd *cobra.Command, _ []string) {
		wapi := getWrapperAPI(cmd)
		if !wapi.IsScriptEnabled() {
			wapi.API().PrintStats()
		}
	}

	rootCmd.AddCommand(newStatsCmd())
	return rootCmd
}

func newStatsCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "stats",
		Short: "Load, validate and display stats of a model file",
	}

	cmd.Run = func(cmd *cobra.Command, _ []string) {
		con := getModel(cmd)
		con.PrintStats()
	}

	return cmd
}

func getModel(cmd *cobra.Command) *tcf.Connectome {
	modelFile, _ := cmd.Flags().GetString("model")
	if modelFile == "" {
		fmt.Println("--model argument is required")
		os.Exit(1)
	}

	con, err := tcf.FromFile(modelFile)
	if err != nil {
		fmt.Printf("Err: %s\n", err)
		os.Exit(1)
	}

	return con
}

func getWrapperAPI(cmd *cobra.Command) *tcf.Wrapper {
	con := getModel(cmd)

	if luaFile, _ := cmd.Flags().GetString("script"); luaFile != "" {
		con.LuaScript = luaFile
	}

	wapi, err := tcf.NewWrapper(con, logger)
	if err != nil {
		fmt.Printf("Err: %s\n", err)
		os.Exit(1)
	}

	return wapi
}
