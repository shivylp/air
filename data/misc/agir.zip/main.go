package main

import (
	"github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
)

var logger = logrus.New()
var rootCmd = &cobra.Command{
	Use:   "agir",
	Short: "AGIR CLI",
}

func main() {
	rootCmd.PersistentFlags().IntP("log-level", "l", 4, "Set log level")

	cobra.OnInitialize(onInit)
	rootCmd.Execute()
}

func onInit() {
	val, _ := rootCmd.Flags().GetInt("log-level")
	logger.SetLevel(logrus.Level(val))
}
