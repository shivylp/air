package main

import (
	"fmt"

	"github.com/spf13/cobra"
)

func init() {
	rootCmd.AddCommand(newExptCmd())
}

func newExptCmd() *cobra.Command {
	cmd := &cobra.Command{
		Use:   "expt",
		Short: "Experimentation Command",
	}

	cmd.Run = func(cmd *cobra.Command, args []string) {
		fmt.Println("add experimentation commands here!")
	}

	return cmd
}
